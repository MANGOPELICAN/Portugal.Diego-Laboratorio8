package grafico;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import logica.Estudiantes;
import logica.Becas;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Formulario extends JFrame {

    // Componentes de la interfaz gráfica
    private JPanel contentPane;
    private JTextField textNombre;
    private JTextField textIndice;
    private JTextField textCedula;
    private JComboBox<String> comboBoxCarreras;
    private JComboBox<String> comboBoxSexo;
    
    // Listas y objetos para manejar los datos
    private ArrayList<Estudiantes> estudiantes;
    private Becas becas;

    // Método main para iniciar la aplicación
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Formulario frame = new Formulario();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    // Constructor
    public Formulario() {
        estudiantes = new ArrayList<>();
        becas = new Becas();
        
        // Configuración de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 932, 552);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // Creación y configuración de los componentes de la interfaz
        JLabel lblNewLabel = new JLabel("Información de estudiantes");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
        lblNewLabel.setBounds(277, 10, 271, 62);
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("Nombre:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_1.setBounds(21, 97, 95, 22);
        contentPane.add(lblNewLabel_1);
        
        textNombre = new JTextField();
        textNombre.setFont(new Font("Tahoma", Font.PLAIN, 20));
        textNombre.setBounds(141, 102, 153, 19);
        contentPane.add(textNombre);
        textNombre.setColumns(10);
        
        JLabel lblNewLabel_1_1 = new JLabel("Indice:");
        lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_1_1.setBounds(21, 239, 95, 22);
        contentPane.add(lblNewLabel_1_1);
        
        textIndice = new JTextField();
        textIndice.setFont(new Font("Tahoma", Font.PLAIN, 20));
        textIndice.setColumns(10);
        textIndice.setBounds(141, 240, 153, 19);
        contentPane.add(textIndice);
        
        JLabel lblNewLabel_1_1_1 = new JLabel("Cédula:");
        lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_1_1_1.setBounds(21, 166, 95, 22);
        contentPane.add(lblNewLabel_1_1_1);
        
        textCedula = new JTextField();
        textCedula.setFont(new Font("Tahoma", Font.PLAIN, 20));
        textCedula.setColumns(10);
        textCedula.setBounds(141, 167, 153, 19);
        contentPane.add(textCedula);
        
        JLabel lblNewLabel_1_1_2 = new JLabel("Carrera:");
        lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_1_1_2.setBounds(21, 308, 95, 22);
        contentPane.add(lblNewLabel_1_1_2);
        
        comboBoxCarreras = new JComboBox<>();
        comboBoxCarreras.setModel(new DefaultComboBoxModel<>(new String[] {"Ingeniería Civil", "Ingeniería Eléctrica", "Ingeniería Industrial", "Ingeniería en Sistemas", "Ingeniería Mecánica", "Ingeniería Marítima"}));
        comboBoxCarreras.setBounds(141, 312, 153, 21);
        comboBoxCarreras.setSelectedIndex(-1);
        contentPane.add(comboBoxCarreras);
        
        JLabel lblNewLabel_1_1_3 = new JLabel("Sexo:");
        lblNewLabel_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_1_1_3.setBounds(21, 377, 95, 22);
        contentPane.add(lblNewLabel_1_1_3);
        
        comboBoxSexo = new JComboBox<>();
        comboBoxSexo.setModel(new DefaultComboBoxModel<>(new String[] {"Masculino", "Femenino"}));
        comboBoxSexo.setBounds(141, 381, 153, 21);
        comboBoxSexo.setSelectedIndex(-1);
        contentPane.add(comboBoxSexo);
        
        // Configuración de los botones y sus ActionListeners
        JButton btnGuardar = new JButton("Guardar Datos");
        btnGuardar.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnGuardar.setBounds(460, 163, 184, 34);
        contentPane.add(btnGuardar);
        
        JButton btnReportes = new JButton("Mostrar Reportes");
        btnReportes.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnReportes.setBounds(700, 361, 184, 34);
        contentPane.add(btnReportes);
        
        JButton btnBuscar = new JButton("Buscar por Cédula");
        btnBuscar.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnBuscar.setBounds(460, 223, 184, 34);
        contentPane.add(btnBuscar);
        
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarDatos();
            }
        });
        
        btnReportes.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirVentanaReportes();
            }
        });
        
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarPorCedula();
            }
        });
    }
    
    // Método para guardar los datos del estudiante
    private void guardarDatos() {
        try {
            // Obtener datos de los campos de texto
            String nombre = textNombre.getText();
            String cedula = textCedula.getText();
            double indice = Double.parseDouble(textIndice.getText());
            String carrera = (String) comboBoxCarreras.getSelectedItem();
            String sexo = (String) comboBoxSexo.getSelectedItem();
            
            // Validar el índice
            if (indice < 0 || indice > 3) {
                throw new IllegalArgumentException("El índice debe estar entre 0 y 3.");
            }
            
            // Crear y guardar el estudiante
            Estudiantes estudiante = new Estudiantes(nombre, cedula, carrera, indice, sexo);
            estudiantes.add(estudiante);
            becas.agregarEstudiante(estudiante);
            
            // Mostrar mensaje de éxito
            System.out.println("Información del estudiante guardada: " + estudiante.toString());
            JOptionPane.showMessageDialog(this, "Información guardada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            limpiarCampos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un valor numérico válido para el índice.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para buscar un estudiante por cédula
    private void buscarPorCedula() {
        String cedula = JOptionPane.showInputDialog(this, "Ingrese la cédula a buscar:");
        if (cedula != null && !cedula.isEmpty()) {
            Estudiantes estudiante = becas.buscarPorCedula(cedula);
            if (estudiante != null) {
                JOptionPane.showMessageDialog(this, "Estudiante encontrado:\n" + estudiante.toString(), "Resultado de búsqueda", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró ningún estudiante con esa cédula.", "Resultado de búsqueda", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    // Método para limpiar los campos después de guardar
    private void limpiarCampos() {
        textNombre.setText("");
        textCedula.setText("");
        textIndice.setText("");
        comboBoxCarreras.setSelectedIndex(-1);
        comboBoxSexo.setSelectedIndex(-1);
    }

    // Método para abrir la ventana de reportes
    private void abrirVentanaReportes() {
        dispose();
        Reportes reportes = new Reportes();
        reportes.setVisible(true);
        reportes.mostrarBecados(becas);
    }
}