package grafico;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import logica.Becas;
import logica.Estudiantes;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Reportes extends JFrame {
    // Componentes de la interfaz gráfica
    private JTextArea textAreaBecados;
    private JPanel contentPane;
    private JComboBox<String> comboBoxCarrera;
    private JComboBox<String> comboBoxSexo;
    private Becas becas;

    // Método main para iniciar la aplicación
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Reportes frame = new Reportes();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    // Constructor
    public Reportes() {
        // Configuración de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 666, 483);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // Creación y configuración de los componentes de la interfaz
        JLabel lblNewLabel = new JLabel("Reportes");
        lblNewLabel.setBounds(238, 10, 149, 46);
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 32));
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("Estudiantes Becados:");
        lblNewLabel_1.setBounds(52, 106, 221, 35);
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        contentPane.add(lblNewLabel_1);
        
        // Área de texto para mostrar los resultados
        textAreaBecados = new JTextArea();
        textAreaBecados.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textAreaBecados);
        scrollPane.setBounds(52, 151, 550, 220);
        contentPane.add(scrollPane);
        
        // ComboBox para seleccionar la carrera
        JLabel lblCarrera = new JLabel("Carrera:");
        lblCarrera.setBounds(52, 390, 80, 25);
        contentPane.add(lblCarrera);
        
        comboBoxCarrera = new JComboBox<>();
        comboBoxCarrera.setModel(new DefaultComboBoxModel<>(new String[] {"Ingeniería Civil", "Ingeniería Eléctrica", "Ingeniería Industrial", "Ingeniería en Sistemas", "Ingeniería Mecánica", "Ingeniería Marítima"}));
        comboBoxCarrera.setBounds(140, 390, 200, 25);
        contentPane.add(comboBoxCarrera);
        
        // ComboBox para seleccionar el sexo
        JLabel lblSexo = new JLabel("Sexo:");
        lblSexo.setBounds(350, 390, 80, 25);
        contentPane.add(lblSexo);
        
        comboBoxSexo = new JComboBox<>();
        comboBoxSexo.setModel(new DefaultComboBoxModel<>(new String[] {"Masculino", "Femenino"}));
        comboBoxSexo.setBounds(430, 390, 100, 25);
        contentPane.add(comboBoxSexo);
        
        // Botón para buscar becados
        JButton btnBuscar = new JButton("Buscar Becados");
        btnBuscar.setBounds(250, 420, 150, 25);
        contentPane.add(btnBuscar);
        
        // ActionListener para el botón de búsqueda
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarBecadosPorCarreraYSexo();
            }
        });
    }

    // Método para mostrar todos los becados
    void mostrarBecados(Becas becas) {
        this.becas = becas;
        System.out.println("Estudiantes becados obtenidos: " + becas.obtenerEstudiantesBecados().size());
        StringBuilder sb = new StringBuilder();
        sb.append("Nombres de los Estudiantes Becados:\n");
        for (String nombre : becas.obtenerEstudiantesBecados()) {
            sb.append(nombre).append("\n");
        }
        textAreaBecados.setText(sb.toString());
    }

    // Método para buscar becados por carrera y sexo
    private void buscarBecadosPorCarreraYSexo() {
        String carrera = (String) comboBoxCarrera.getSelectedItem();
        String sexo = (String) comboBoxSexo.getSelectedItem();
        
        // Validar que se haya seleccionado una carrera y un sexo
        if (carrera == null || sexo == null) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una carrera y un sexo.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Obtener la lista de becados filtrada
        ArrayList<Estudiantes> becadosFiltrados = becas.buscarBecadosPorCarreraYSexo(carrera, sexo);
        
        // Construir el string con los resultados
        StringBuilder sb = new StringBuilder();
        sb.append("Estudiantes Becados (").append(carrera).append(", ").append(sexo).append("):\n\n");
        
        if (becadosFiltrados.isEmpty()) {
            sb.append("No se encontraron estudiantes becados con los criterios seleccionados.");
        } else {
            for (Estudiantes estudiante : becadosFiltrados) {
                sb.append(estudiante.toString()).append("\n");
            }
        }
        
        // Mostrar los resultados en el área de texto
        textAreaBecados.setText(sb.toString());
    }
}