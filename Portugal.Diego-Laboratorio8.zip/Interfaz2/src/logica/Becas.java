package logica;
import java.util.ArrayList;

public class Becas {
    // Constante para el número máximo de estudiantes
    private static final int MAX_ESTUDIANTES = 100;
    // Lista para almacenar los estudiantes
    private ArrayList<Estudiantes> estudiantes;

    // Constructor
    public Becas() {
        estudiantes = new ArrayList<>();
    }

    // Método para agregar un estudiante
    public void agregarEstudiante(Estudiantes estudiante) {
        if (estudiantes.size() < MAX_ESTUDIANTES) {
            estudiantes.add(estudiante);
        } else {
            System.out.println("No se puede agregar más estudiantes. Límite alcanzado.");
        }
    }

    // Método para obtener la lista de estudiantes becados
    public ArrayList<String> obtenerEstudiantesBecados() {
        ArrayList<String> estudiantesBecados = new ArrayList<>();
        for (Estudiantes estudiante : estudiantes) {
            if (estudiante.getIndiceAcademico() >= 2.0) {
                estudiantesBecados.add(estudiante.getNombre());
            }
        }
        return estudiantesBecados;
    }

    // Método para buscar un estudiante por cédula
    public Estudiantes buscarPorCedula(String cedula) {
        for (Estudiantes estudiante : estudiantes) {
            if (estudiante.getCedula().equals(cedula)) {
                return estudiante;
            }
        }
        return null;
    }

    // Método para buscar becados por carrera y sexo
    public ArrayList<Estudiantes> buscarBecadosPorCarreraYSexo(String carrera, String sexo) {
        ArrayList<Estudiantes> becados = new ArrayList<>();
        for (Estudiantes estudiante : estudiantes) {
            if (estudiante.getIndiceAcademico() >= 2.0 &&
                estudiante.getCarrera().equals(carrera) &&
                estudiante.getSexo().equals(sexo)) {
                becados.add(estudiante);
            }
        }
        return becados;
    }
}