package logica;

public class Estudiantes {
    // Atributos de la clase
    private String nombre;
    private String cedula;
    private String carrera;
    private double indiceAcademico;
    private String sexo;

    // Constructor
    public Estudiantes(String nombre, String cedula, String carrera, double indiceAcademico, String sexo) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.carrera = carrera;
        this.indiceAcademico = indiceAcademico;
        this.sexo = sexo;
    }

    // Métodos getter
    public double getIndiceAcademico() {
        return indiceAcademico;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public String getCarrera() {
        return carrera;
    }

    public String getSexo() {
        return sexo;
    }

    // Método toString para representación en cadena del objeto
    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Cédula: " + cedula + ", Carrera: " + carrera + 
               ", Índice: " + indiceAcademico + ", Sexo: " + sexo;
    }
}